import React from 'react';
const Home = () => {
    return(
        <div>
        <center><h1>home page</h1></center>
        </div>
    )
}
export default Home