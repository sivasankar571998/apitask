import React from 'react';
const Contact = () => {
    return(
        <div>
        <center><h1>contact page</h1></center>
        </div>
    )
}

export default Contact