import React from 'react'
import {Link} from 'react-router-dom'
const Header = () =>{
    return(
        <>
        <center>
        <ul>
            <Link to="/home"><li>Home</li></Link>
            <Link to="/menu"><li>Menu</li></Link>
            <Link to="/contact"><li>Contact</li></Link>
            <Link to="/App"><li>Api</li></Link>
        </ul>
        </center>
        </>
    )
}
export default Header