import React from 'react'
import {useState} from 'react'

const Inc = () => {
    const [val,setVal] = useState(1)
    const Increment = () => {
        if(val >=1 && val <10) {
            setVal(val+1)
        }
    }
    const Decrement = () => {
        if(val >1 && val <10) {
            setVal(val-1)
        }
    }
    return(
        <center>
        <h1>{val}</h1>
        <button className="btn btn-primary pl-3" onClick={Increment}>Increase</button>
        <button className="btn btn-primary" onClick={Decrement}>Decrease</button>
        </center>
    )
}
export default Inc