import React from 'react';
const Menu = () => {
    return(
        <div>
        <center><h1>menu page</h1></center>
        </div>
    )
}


export default Menu