import React, { useEffect } from 'react'
import axios from 'axios'
import {useState} from 'react'


const App = () => {
  const [data,setData] = useState()
  
  useEffect(()=> {
    axios.get("https://api.pujakaitem.com/api/products").then(da=> setData(da.data))
    console.log(data)
    },[])
  return(
    <>
  {data && data.map((each)=> {
    return(
    
      <>
      <div className="container">
        <div className="row">
       {data.map((each)=> {
    return(
    
      
      
      <li key={each.id} className="d-flex flex-row col-md-4">
      <div className="card">
  <img className="card-img-top" src={each.image}alt="Card image cap"/>
  <div className="card-body">
    <h5 className="card-title">{each.company}</h5>
    <h5 className="card-title">{each.name}</h5>
    <p className="card-text">{each.description}</p>
    
  </div>
</div>
      </li> 
      
    
      
    )
  })}</div></div>
      </>
      
    )
  })}
  </>);
}
export default App