import React, { useEffect } from 'react'
//import axios from 'axios'
//import {useState} from 'react'
import App from './components/api/api.js'
import './components/header.css'
import Home from './components/Home'
import Menu from './components/Menu'
import Contact from './components/Contact'
import Inc from './components/IncDec/inc.js'
import Header from './components/Header/header.js'
import{BrowserRouter,Route,Switch} from 'react-router-dom'
const Appp = () => {
  
  return(
    <>
  
  <BrowserRouter>
  <Header/>
  <Inc/>
  <Switch>
    <Route exact path="/Home" component={Home}/>
    <Route exact path="/App" component={App}/>
    <Route exact path="/menu" component={Menu}/>
    <Route exact path="/contact" component={Contact}/>
  </Switch>
  </BrowserRouter>

  </>);
}
export default Appp